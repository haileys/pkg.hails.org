#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/usr/x86_64-linux-gnux32/lib"
XML2_LIBS="-lxml2 -lm "
XML2_INCLUDEDIR="-I/usr/x86_64-linux-gnux32/include/libxml2"
MODULE_VERSION="xml2-2.9.14"

