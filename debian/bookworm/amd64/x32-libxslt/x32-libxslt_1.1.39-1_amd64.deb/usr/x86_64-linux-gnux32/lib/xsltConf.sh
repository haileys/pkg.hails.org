#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/usr/x86_64-linux-gnux32/lib"
XSLT_LIBS="-lxslt -L/usr/x86_64-linux-gnux32/lib -lxml2 "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/usr/x86_64-linux-gnux32/include"
MODULE_VERSION="xslt-1.1.39"
